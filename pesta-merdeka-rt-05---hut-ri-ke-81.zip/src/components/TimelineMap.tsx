import React, { useState } from 'react';
import { TimelineEvent, PhotoDocumentation } from '../types';
import { Calendar, MapPin, Clock, Camera, CheckCircle2, Hourglass, Filter, ChevronRight, Compass, Flag, MousePointerClick } from 'lucide-react';

interface TimelineMapProps {
  events: TimelineEvent[];
  onOpenPhoto: (photo: PhotoDocumentation, allPhotos: PhotoDocumentation[]) => void;
  onOpenEventDetail: (event: TimelineEvent) => void;
}

export const TimelineMap: React.FC<TimelineMapProps> = ({
  events,
  onOpenPhoto,
  onOpenEventDetail,
}) => {
  const [filterStatus, setFilterStatus] = useState<'semua' | 'selesai' | 'mendatang' | 'anak'>('semua');

  // Filter events
  const filteredEvents = events.filter((evt) => {
    if (filterStatus === 'selesai') return evt.status === 'selesai';
    if (filterStatus === 'mendatang') return evt.status === 'mendatang';
    if (filterStatus === 'anak') return evt.isKidFriendly === true;
    return true;
  });

  const getRotationAngle = (index: number) => {
    const angles = ['rotate-[-1.5deg]', 'rotate-[1.5deg]', 'rotate-[-2deg]', 'rotate-[2deg]', 'rotate-[-1deg]', 'rotate-[1.5deg]'];
    return angles[index % angles.length];
  };

  return (
    <section id="timeline-section" className="py-12 bg-[#fefae0] relative overflow-hidden border-b-4 border-black">
      {/* Background treasure map grid pattern */}
      <div className="absolute inset-0 opacity-20 pointer-events-none bg-[radial-gradient(#854d0e_2px,transparent_2px)] [background-size:28px_28px]"></div>

      {/* Decorative Compass & Map Accents */}
      <div className="absolute top-8 right-8 text-amber-900/15 pointer-events-none hidden md:block rotate-12">
        <Compass className="w-32 h-32" />
      </div>
      <div className="absolute bottom-12 left-6 text-amber-900/10 pointer-events-none hidden md:block -rotate-12">
        <Flag className="w-24 h-24" />
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 space-y-3">
          <div className="inline-flex items-center gap-2 bg-amber-300 text-black font-black text-xs sm:text-sm px-4 py-1.5 rounded-full border-3 border-black shadow-[3px_3px_0px_#000] rotate-[-1deg]">
            <Compass className="w-4 h-4 text-red-600 animate-spin" />
            <span>PETA HARTA KARUN ACARA 🏴‍☠️</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-black tracking-tight font-sans">
            Rute Jejak <span className="bg-red-600 text-white px-3 py-1 rounded-2xl border-3 border-black inline-block shadow-[4px_4px_0px_#000] rotate-1">Peta Petualangan</span>
          </h2>

          <p className="text-stone-800 font-bold text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Garis berliku menghubungkan setiap pos acara layaknya peta harta karun! Klik <span className="text-red-600 font-black underline">kartu kecil pos</span> untuk melihat detail kegiatan.
          </p>

          {/* Interactive Hint Banner */}
          <div className="inline-flex items-center gap-2 bg-amber-200 border-2 border-black rounded-xl px-3.5 py-1 text-xs font-black text-stone-900 shadow-[2px_2px_0px_#000]">
            <MousePointerClick className="w-4 h-4 text-red-600 animate-bounce" />
            <span>Klik kartu event untuk melihat detail & foto dokumentasi!</span>
          </div>

          {/* Filter Bar Neubrutalism */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <button
              onClick={() => setFilterStatus('semua')}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs border-2 border-black transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'semua'
                  ? 'bg-amber-400 shadow-[3px_3px_0px_#000] text-black -translate-y-0.5'
                  : 'bg-white hover:bg-stone-100 shadow-[2px_2px_0px_#000] text-stone-700'
              }`}
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Semua ({events.length})</span>
            </button>

            <button
              onClick={() => setFilterStatus('selesai')}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs border-2 border-black transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'selesai'
                  ? 'bg-emerald-300 shadow-[3px_3px_0px_#000] text-black -translate-y-0.5'
                  : 'bg-white hover:bg-emerald-50 shadow-[2px_2px_0px_#000] text-stone-700'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" />
              <span>Selesai ({events.filter(e => e.status === 'selesai').length})</span>
            </button>

            <button
              onClick={() => setFilterStatus('mendatang')}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs border-2 border-black transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'mendatang'
                  ? 'bg-sky-300 shadow-[3px_3px_0px_#000] text-black -translate-y-0.5'
                  : 'bg-white hover:bg-sky-50 shadow-[2px_2px_0px_#000] text-stone-700'
              }`}
            >
              <Hourglass className="w-3.5 h-3.5 text-sky-700" />
              <span>Mendatang ({events.filter(e => e.status === 'mendatang').length})</span>
            </button>

            <button
              onClick={() => setFilterStatus('anak')}
              className={`px-3.5 py-1.5 rounded-xl font-black text-xs border-2 border-black transition-all cursor-pointer flex items-center gap-1.5 ${
                filterStatus === 'anak'
                  ? 'bg-rose-300 shadow-[3px_3px_0px_#000] text-black -translate-y-0.5'
                  : 'bg-white hover:bg-rose-50 shadow-[2px_2px_0px_#000] text-stone-700'
              }`}
            >
              <span>🎈 Ramah Anak</span>
            </button>
          </div>
        </div>

        {/* ROADMAP ADVENTURE MAP AREA */}
        <div className="relative py-4">

          {/* SVG WINDING TREASURE MAP DASHED PATH (DESKTOP) */}
          <div className="absolute inset-0 pointer-events-none hidden lg:block z-0">
            <svg className="w-full h-full" preserveAspectRatio="none" viewBox="0 0 1000 1200">
              {/* Outer Thick Black Dash Outline connecting central axis S-curve */}
              <path
                d="M 500 60 C 200 60, 200 240, 500 240 C 800 240, 800 420, 500 420 C 200 420, 200 600, 500 600 C 800 600, 800 780, 500 780 C 200 780, 200 960, 500 960 C 800 960, 800 1140, 500 1140"
                fill="none"
                stroke="#000"
                strokeWidth="10"
                strokeDasharray="16 12"
                strokeLinecap="round"
              />
              {/* Inner Crimson Red Treasure Path */}
              <path
                d="M 500 60 C 200 60, 200 240, 500 240 C 800 240, 800 420, 500 420 C 200 420, 200 600, 500 600 C 800 600, 800 780, 500 780 C 200 780, 200 960, 500 960 C 800 960, 800 1140, 500 1140"
                fill="none"
                stroke="#dc2626"
                strokeWidth="4"
                strokeDasharray="16 12"
                strokeLinecap="round"
              />
              {/* Decorative Treasure Map Icons along curves */}
              <g>
                <text x="230" y="150" className="text-2xl font-black">🚩</text>
                <text x="750" y="330" className="text-2xl font-black">❌</text>
                <text x="230" y="510" className="text-2xl font-black">🏝️</text>
                <text x="750" y="690" className="text-2xl font-black">❌</text>
                <text x="230" y="870" className="text-2xl font-black">🚩</text>
                <text x="750" y="1050" className="text-2xl font-black">🏆</text>
              </g>
            </svg>
          </div>

          {/* Mobile vertical winding dotted line with map decorations */}
          <div className="absolute left-5 sm:left-7 top-4 bottom-4 w-1 lg:hidden pointer-events-none z-0 border-l-4 border-dashed border-red-600"></div>

          {/* EVENT CARDS - DEDICATED RESPONSIVE MOBILE & DESKTOP LAYOUTS */}
          <div className="space-y-4 lg:space-y-12 relative z-10">
            {filteredEvents.map((evt, index) => {
              const isPast = evt.status === 'selesai';
              const isEven = index % 2 === 0;
              const rotationClass = getRotationAngle(index);

              {/* Desktop Full Card Content */}
              const desktopCardContent = (
                <div
                  onClick={() => onOpenEventDetail(evt)}
                  className={`w-full max-w-[320px] rounded-2xl p-4 transition-all duration-300 transform hover:-translate-y-1.5 hover:scale-[1.02] cursor-pointer group ${rotationClass} ${
                    isPast
                      ? `${evt.bgColor} border-3 border-black shadow-[4px_4px_0px_#000] hover:shadow-[7px_7px_0px_#000]`
                      : `bg-white ${evt.bgColor}/30 border-3 border-dashed border-stone-800 opacity-95 shadow-[4px_4px_0px_rgba(0,0,0,0.8)] hover:shadow-[7px_7px_0px_#000]`
                  }`}
                >
                  {/* CARD HEADER BADGES */}
                  <div className="flex items-center justify-between gap-1.5 mb-2">
                    <div className="flex items-center gap-1">
                      <span className="bg-black text-white text-[10px] font-black px-2 py-0.5 rounded-lg border border-black shadow-[1px_1px_0px_#fff]">
                        POS {evt.stepNumber}
                      </span>
                      <span className="bg-white text-black text-[10px] font-extrabold px-2 py-0.5 rounded-lg border border-black shadow-[1px_1px_0px_#000] truncate max-w-[100px]">
                        {evt.category}
                      </span>
                    </div>

                    {isPast ? (
                      <span className="bg-emerald-400 text-black text-[10px] font-black px-2 py-0.5 rounded-lg border border-black flex items-center gap-0.5 shrink-0">
                        <CheckCircle2 className="w-3 h-3 text-emerald-950 fill-emerald-200" />
                        <span>SELESAI</span>
                      </span>
                    ) : (
                      <span className="bg-amber-300 text-stone-900 text-[10px] font-black px-2 py-0.5 rounded-lg border border-black flex items-center gap-0.5 shrink-0">
                        <Hourglass className="w-3 h-3 text-amber-900" />
                        <span>MENDATANG</span>
                      </span>
                    )}
                  </div>

                  {/* EMOJI & TITLE */}
                  <div className="flex items-start gap-2.5 mb-2">
                    <div className="w-11 h-11 bg-white rounded-xl border-2 border-black shadow-[2px_2px_0px_#000] flex items-center justify-center text-2xl shrink-0 transform group-hover:scale-110 group-hover:rotate-6 transition-transform">
                      {evt.emoji}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="text-[10px] font-black text-red-600 uppercase tracking-wider flex items-center gap-1">
                        <Calendar className="w-3 h-3 inline shrink-0" />
                        <span>{evt.date}</span>
                      </div>

                      <h3 className="text-base font-black text-black leading-tight group-hover:text-red-600 transition-colors mt-0.5 truncate">
                        {evt.title}
                      </h3>

                      <p className="text-[11px] font-bold text-stone-700 truncate">
                        {evt.subtitle}
                      </p>
                    </div>
                  </div>

                  {/* TIME & LOCATION */}
                  <div className="flex items-center gap-1.5 text-[10px] font-bold text-stone-800 bg-white/90 px-2 py-1 rounded-lg border border-black mb-2">
                    <span className="flex items-center gap-0.5 shrink-0">
                      <Clock className="w-3 h-3 text-amber-600" />
                      {evt.time}
                    </span>
                    <span>•</span>
                    <span className="flex items-center gap-0.5 truncate">
                      <MapPin className="w-3 h-3 text-red-600 shrink-0" />
                      <span className="truncate">{evt.location}</span>
                    </span>
                  </div>

                  {/* FOOTER ACTION */}
                  <div className="pt-2 border-t border-black/20 flex items-center justify-between text-[11px]">
                    {evt.photos.length > 0 ? (
                      <div className="flex items-center gap-1 text-[10px] font-black text-stone-800">
                        <Camera className="w-3 h-3 text-stone-700" />
                        <span>{evt.photos.length} Foto</span>
                      </div>
                    ) : (
                      <span className="text-[10px] font-bold text-stone-500">
                        📷 Info Pos
                      </span>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenEventDetail(evt);
                      }}
                      className="bg-black text-white hover:bg-stone-800 font-black text-[10px] px-2.5 py-1 rounded-lg border border-black shadow-[1.5px_1.5px_0px_#000] flex items-center gap-1 cursor-pointer group-hover:scale-105 transition-transform"
                    >
                      <span>Buka Detail</span>
                      <ChevronRight className="w-3 h-3 text-amber-300" />
                    </button>
                  </div>
                </div>
              );

              return (
                <React.Fragment key={evt.id}>
                  {/* MOBILE LAYOUT (< lg) - COMPACT MAP CARD */}
                  <div className="flex lg:hidden items-center gap-2.5 pl-1.5 sm:pl-3 relative z-10 my-2">
                    {/* POS Node on the Map Path */}
                    <div
                      onClick={() => onOpenEventDetail(evt)}
                      className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-300 border-2 border-black shadow-[2px_2px_0px_#000] flex items-center justify-center font-black text-[10px] sm:text-xs text-black cursor-pointer shrink-0 active:scale-90 transition-transform z-10"
                    >
                      P{evt.stepNumber}
                    </div>

                    {/* Compact Card: Shows Title, Date & Click trigger */}
                    <div
                      onClick={() => onOpenEventDetail(evt)}
                      className={`flex-1 min-w-0 rounded-xl px-3 py-2 border-2 border-black transition-all cursor-pointer active:scale-98 shadow-[2.5px_2.5px_0px_#000] ${
                        isPast
                          ? `${evt.bgColor} bg-opacity-95`
                          : `bg-white ${evt.bgColor}/30 border-dashed`
                      }`}
                    >
                      <div className="flex items-center justify-between gap-1.5">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="text-base sm:text-lg shrink-0">{evt.emoji}</span>
                          <div className="min-w-0">
                            <h4 className="text-xs sm:text-sm font-black text-black leading-tight truncate">
                              {evt.title}
                            </h4>
                            <div className="text-[10px] font-bold text-red-600 flex items-center gap-1 mt-0.5">
                              <Calendar className="w-2.5 h-2.5 inline shrink-0" />
                              <span className="truncate">{evt.date}</span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          {isPast ? (
                            <span className="bg-emerald-400 text-black text-[9px] font-black px-1.5 py-0.5 rounded border border-black">
                              Selesai
                            </span>
                          ) : (
                            <span className="bg-amber-300 text-stone-900 text-[9px] font-black px-1.5 py-0.5 rounded border border-black">
                              Mendatang
                            </span>
                          )}
                          <ChevronRight className="w-3.5 h-3.5 text-black" />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* DESKTOP LAYOUT (>= lg) */}
                  <div className="hidden lg:grid lg:grid-cols-[1fr_auto_1fr] items-center gap-8 relative z-10">
                    {/* LEFT COLUMN */}
                    <div className="w-full flex justify-end">
                      {isEven ? desktopCardContent : <div className="w-[320px] pointer-events-none opacity-0"></div>}
                    </div>

                    {/* CENTER POS BADGE */}
                    <div className="flex flex-col items-center justify-center z-20 shrink-0">
                      <div
                        onClick={() => onOpenEventDetail(evt)}
                        className="w-12 h-12 rounded-2xl bg-amber-300 border-3 border-black shadow-[3px_3px_0px_#000] flex items-center justify-center font-black text-sm text-black transform hover:scale-110 transition-transform cursor-pointer"
                      >
                        POS {evt.stepNumber}
                      </div>
                    </div>

                    {/* RIGHT COLUMN */}
                    <div className="w-full flex justify-start">
                      {!isEven ? desktopCardContent : <div className="w-[320px] pointer-events-none opacity-0"></div>}
                    </div>
                  </div>
                </React.Fragment>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};


