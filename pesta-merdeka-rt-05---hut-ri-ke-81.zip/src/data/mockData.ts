import { TimelineEvent, LombaItem, ResidentWish } from '../types';

export const INITIAL_EVENTS: TimelineEvent[] = [
  {
    id: 'evt-1',
    stepNumber: 1,
    title: 'Kerja Bakti & Pemasangan Bendera RT',
    subtitle: 'Gotong Royong Perapihan Lapangan & Hias Portal',
    date: 'Ahad, 2 Agustus 2026',
    time: '07.00 - 11.00 WIB',
    location: 'Lapangan Utama & Pos Ronda RT 05',
    category: 'Pra-Acara',
    status: 'selesai',
    emoji: '🧹🇮🇩',
    bgColor: 'bg-red-100',
    accentColor: 'border-red-600',
    description: 'Seluruh warga RT 05 bahu-membahu membersihkan selokan, ngecat gapura merah putih, dan memasang 81 umbul-umbul serta bendera Merah Putih di setiap gang.',
    highlights: ['Pengecatan Gapura Merah Putih', 'Pemasangan Lampu Hias', 'Sarapan Nasi Uduk Bersama'],
    photos: [
      {
        id: 'p1',
        url: 'https://images.unsplash.com/photo-1577495508048-b635879837f1?auto=format&fit=crop&w=800&q=80',
        caption: 'Warga semangat mengecat dinding Pos Ronda dengan tema HUT RI 81',
        photographer: 'Pak Budi RT'
      },
      {
        id: 'p2',
        url: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?auto=format&fit=crop&w=800&q=80',
        caption: 'Pemasangan bendera & umbul-umbul di sepanjang jalan RT 05',
        photographer: 'Karang Taruna'
      },
      {
        id: 'p3',
        url: 'https://images.unsplash.com/photo-1528605248644-14dd04022da1?auto=format&fit=crop&w=800&q=80',
        caption: 'Makan bareng Nasi Uduk racikan Ibu-Ibu PKK setelah kerja bakti',
        photographer: 'Bu RT Endang'
      }
    ],
    isKidFriendly: true
  },
  {
    id: 'evt-2',
    stepNumber: 2,
    title: 'Pekan Lomba Anak-Anak & Ceria',
    subtitle: 'Kerupuk, Balap Karung Helm, & Kelereng Sendok',
    date: 'Sabtu, 8 Agustus 2026',
    time: '08.00 - 12.00 WIB',
    location: 'Lapangan Bulutangkis RT 05',
    category: 'Lomba',
    status: 'selesai',
    emoji: '🎈🏃‍♂️',
    bgColor: 'bg-amber-100',
    accentColor: 'border-amber-600',
    description: 'Keceriaan anak-anak RT 05 berlomba memakan kerupuk jumbo, balap karung memakai helm lucu, serta estafet air keliling lapangan.',
    highlights: ['Lomba Makan Kerupuk Raksasa', 'Balap Karung Helm Safety', 'Memasukkan Paku ke Botol'],
    photos: [
      {
        id: 'p4',
        url: 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&w=800&q=80',
        caption: 'Anak-anak riang gembira saat penyerahan hadiah babak penyisihan',
        photographer: 'Mas Rizky'
      },
      {
        id: 'p5',
        url: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&w=800&q=80',
        caption: 'Keseruan anak-anak TK & SD mengejar balon warna-warni',
        photographer: 'Mba Siska'
      },
      {
        id: 'p6',
        url: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=800&q=80',
        caption: 'Juara 1 Lomba Kelereng Sendok kategori PAUD',
        photographer: 'Pak Budi RT'
      }
    ],
    isKidFriendly: true
  },
  {
    id: 'evt-3',
    stepNumber: 3,
    title: 'Lomba Ibu-Ibu & Bapak-Bapak Heboh',
    subtitle: 'Tarik Tambang, Voli Plastik & Make-up Tutup Mata',
    date: 'Minggu, 9 Agustus 2026',
    time: '15.30 - 18.00 WIB',
    location: 'Area Jalan Utama RT 05',
    category: 'Lomba',
    status: 'selesai',
    emoji: '💪😂',
    bgColor: 'bg-rose-100',
    accentColor: 'border-red-600',
    description: 'Ajang kekompakan bapak-bapak dan ibu-ibu! Pertandingan tarik tambang antar-gang yang penuh gelak tawa dan semangat persaudaraan.',
    highlights: ['Tarik Tambang Antar Gang', 'Lomba Bapak Merias Ibu (Mata Tertutup)', 'Sepakbola Pakai Daster'],
    photos: [
      {
        id: 'p7',
        url: 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80',
        caption: 'Sorak semangat suporter Gang Merpati vs Gang Garuda',
        photographer: 'Karang Taruna'
      },
      {
        id: 'p8',
        url: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205?auto=format&fit=crop&w=800&q=80',
        caption: 'Momen heboh Tarik Tambang antar Gang di sore hari',
        photographer: 'Pak RT Agus'
      }
    ],
    isKidFriendly: false
  },
  {
    id: 'evt-4',
    stepNumber: 4,
    title: 'Malam Tasyakuran & Doa Bersama',
    subtitle: 'Potong 81 Tumpeng & Renungan Kemerdekaan',
    date: 'Sabtu, 15 Agustus 2026',
    time: '19.30 - 22.00 WIB',
    location: 'Pendopo Pos Ronda RT 05',
    category: 'Religi/Budaya',
    status: 'mendatang',
    emoji: '🍚✨',
    bgColor: 'bg-amber-100',
    accentColor: 'border-amber-600',
    description: 'Malam khidmat penuh rasa syukur atas 81 tahun kemerdekaan Republik Indonesia. Pemotongan tumpeng utama, doa bersama tokoh masyarakat, serta kisah pahlawan untuk anak-anak.',
    highlights: ['Pemotongan Tumpeng Kemerdekaan', 'Santunan Anak Yatim RT', 'Nobar Film Dokumenter Sejarah RI'],
    photos: [
      {
        id: 'p9',
        url: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=800&q=80',
        caption: 'Ilustrasi persiapan Tumpeng Merah Putih kreasi Ibu PKK',
        photographer: 'Panitia Tasyakuran'
      },
      {
        id: 'p10',
        url: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=800&q=80',
        caption: 'Suasana kehangatan kumpul warga di malam tasyakuran (Tahun lalu)',
        photographer: 'Arsip RT 05'
      }
    ],
    isKidFriendly: true
  },
  {
    id: 'evt-5',
    stepNumber: 5,
    title: 'Upacara Merdeka & Karnaval Sepeda Hias',
    subtitle: 'Parade Pakaian Adat Cilik & Sepeda Hias 81',
    date: 'Ahad, 17 Agustus 2026',
    time: '07.00 - 11.30 WIB',
    location: 'Halaman Pos RT -> Keliling Komplek',
    category: 'Pra-Acara',
    status: 'mendatang',
    emoji: '🚲🇮🇩',
    bgColor: 'bg-red-100',
    accentColor: 'border-red-600',
    description: 'Puncak peringatan detik-detik Proklamasi di tingkat RT dilanjutkan Karnaval Budaya dan Parade Sepeda Hias kreasi anak-anak dengan berbagai pernak-pernik kreatif.',
    highlights: ['Upacara Pengibaran Bendera RT 05', 'Parade Sepeda Hias Anak', 'Fashion Show Baju Adat Nusantara Cilik'],
    photos: [
      {
        id: 'p11',
        url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80',
        caption: 'Persiapan anak-anak memakai pakaian tradisional Nusantara',
        photographer: 'Panitia Karnaval'
      }
    ],
    isKidFriendly: true
  },
  {
    id: 'evt-6',
    stepNumber: 6,
    title: 'Malam Puncak & Panggung Gembira RT 05',
    subtitle: 'Pentas Seni Anak, Pembagian Hadiah & Doorprise Raksasa',
    date: 'Sabtu, 22 Agustus 2026',
    time: '19.00 - 23.00 WIB',
    location: 'Panggung Utama Lapangan Bulutangkis RT 05',
    category: 'Puncak Acara',
    status: 'mendatang',
    emoji: '🎭🎁',
    bgColor: 'bg-red-200',
    accentColor: 'border-red-700',
    description: 'Acara penutup yang paling ditunggu! Penampilan tari tradisional anak-anak, band lokal Karang Taruna, pembagian piala semua lomba, dan pengundian doorprize Sepeda Listrik & Kipas Angin!',
    highlights: ['Pentas Tari Tradisional Anak RT', 'Penyerahan Piala & Piagam Juara Lomba', 'Pengundian Doorprise Utama Sepeda Listrik'],
    photos: [
      {
        id: 'p12',
        url: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
        caption: 'Kemegahan Panggung Pentas Seni RT 05 (Pratinjau)',
        photographer: 'Panitia Puncak'
      }
    ],
    isKidFriendly: true
  }
];

export const INITIAL_LOMBA: LombaItem[] = [
  {
    id: 'l-1',
    title: 'Makan Kerupuk Raksasa',
    category: 'Anak-Anak',
    emoji: '🥨',
    date: 'Sabtu, 8 Agustus 2026',
    time: '08.30 WIB',
    location: 'Lapangan Bulutangkis',
    picName: 'Kak Doni (Karang Taruna)',
    picPhone: '0812-3456-7890',
    registeredCount: 18,
    maxParticipants: 24,
    prizes: ['Trofi Juara 1 + Set Alat Tulis Komplek', 'Trofi Juara 2 + Tas Sekolah', 'Trofi Juara 3 + Botol Minum Tumbler'],
    rules: ['Kategori usia 5 - 10 tahun', 'Tangan wajib diikat ke belakang', 'Dilarang menyentuh tali kerupuk dengan sengaja'],
    bgColor: 'bg-amber-100',
    status: 'Selesai'
  },
  {
    id: 'l-2',
    title: 'Balap Karung Pakai Helm Safety',
    category: 'Anak-Anak',
    emoji: '🪖',
    date: 'Sabtu, 8 Agustus 2026',
    time: '10.00 WIB',
    location: 'Lapangan Bulutangkis',
    picName: 'Kak Aulia',
    picPhone: '0813-9876-5432',
    registeredCount: 16,
    maxParticipants: 20,
    prizes: ['Piala Juara 1 + Sepatu Roda', 'Piala Juara 2 + Helm Lucu', 'Piala Juara 3 + Set Mewarnai'],
    rules: ['Wajib memakai helm yang disediakan panitia', 'Lompat dari garis start hingga finish tanpa jatuh', 'Usia 8 - 14 tahun'],
    bgColor: 'bg-sky-100',
    status: 'Selesai'
  },
  {
    id: 'l-3',
    title: 'Karnaval Sepeda Hias 81',
    category: 'Anak-Anak',
    emoji: '🚲',
    date: 'Ahad, 17 Agustus 2026',
    time: '08.00 WIB',
    location: 'Halaman Pos RT 05',
    picName: 'Bu RT Endang',
    picPhone: '0811-2233-4455',
    registeredCount: 22,
    maxParticipants: 35,
    prizes: ['Sepeda Gunung Juara 1', 'Piala + Voucher Gramedia Juara 2', 'Piala + Paket Alat Tulis Juara 3'],
    rules: ['Tema hiasan Merah Putih / HUT RI ke-81', 'Aman dikendarai anak keliling kompleks', 'Didampingi orang tua untuk kategori balita'],
    bgColor: 'bg-rose-100',
    status: 'Pendaftaran Dibuka'
  },
  {
    id: 'l-4',
    title: 'Merias Wajah Tutup Mata (Bapak-Ibu)',
    category: 'Umum',
    emoji: '💄',
    date: 'Minggu, 9 Agustus 2026',
    time: '16.00 WIB',
    location: 'Jalan Utama Gang 2',
    picName: 'Bu Nunung',
    picPhone: '0857-1122-3344',
    registeredCount: 12,
    maxParticipants: 12,
    prizes: ['Set Alat Masak Premium (Juara 1)', 'Voucher Belanja Sembako 300rb', 'Paket Perabotan Rumah'],
    rules: ['Satu tim terdiri dari Suami & Istri', 'Bapak menutup mata rapat dengan kain merah', 'Waktu merias maksimal 5 menit'],
    bgColor: 'bg-purple-100',
    status: 'Selesai'
  },
  {
    id: 'l-5',
    title: 'Tarik Tambang Antar Gang',
    category: 'Bapak-Bapak',
    emoji: '💪',
    date: 'Minggu, 9 Agustus 2026',
    time: '16.30 WIB',
    location: 'Lapangan Utama',
    picName: 'Pak Budi RT',
    picPhone: '0818-7788-9900',
    registeredCount: 8,
    maxParticipants: 8,
    prizes: ['Kambing Kambing Kurban/Hadiah Tunai 1.5 Juta', 'Trofi + Parcel Sembako Raksasa', 'Parcel Snack Komplek'],
    rules: ['1 Tim terdiri dari 5 warga RT 05 per Gang', 'Sistem gugur best of 3', 'Wajib memakai sepatu olahraga'],
    bgColor: 'bg-emerald-100',
    status: 'Selesai'
  },
  {
    id: 'l-6',
    title: 'Kreasi Tumpeng Mini Ibu PKK',
    category: 'Ibu-Ibu',
    emoji: '🍱',
    date: 'Sabtu, 15 Agustus 2026',
    time: '16.00 WIB',
    location: 'Pendopo Pos Ronda',
    picName: 'Bu Sekertaris Titin',
    picPhone: '0812-9900-1122',
    registeredCount: 10,
    maxParticipants: 15,
    prizes: ['Piala Bergilir Ibu PKK + Air Fryer', 'Blender Juara 2', 'Kompor Gas Portable Juara 3'],
    rules: ['Bahan dasar nasi kuning/merah putih', 'Estetika, kerapihan & cita rasa dinilai juri independen', 'Hiasan ramah lingkungan'],
    bgColor: 'bg-yellow-100',
    status: 'Pendaftaran Dibuka'
  }
];

export const INITIAL_WISHES: ResidentWish[] = [
  {
    id: 'w-1',
    name: 'Keluarga Pak Budi',
    houseNumber: 'Rumah No. 12',
    message: 'Dirgahayu Republik Indonesia ke-81! Bangga jadi warga RT 05 yang selalu kompak dan rukun. Merdeka!! 🇮🇩✨',
    sticker: '🇮🇩',
    timestamp: '2 jam yang lalu',
    likes: 12
  },
  {
    id: 'w-2',
    name: 'Kak Alya & Adik Dito',
    houseNumber: 'Rumah No. 04',
    message: 'Nggak sabar ikutan Karnaval Sepeda Hias besok Minggu! Sepedaku sudah dipasang bendera sama Ayah 🚲🎈',
    sticker: '🚲',
    timestamp: '4 jam yang lalu',
    likes: 9
  },
  {
    id: 'w-3',
    name: 'Bu Hajah Nunung',
    houseNumber: 'Rumah No. 25',
    message: 'Semoga acara HUT RI ke-81 RT kita lancar, berkah, dan makin mempererat tali silaturahmi antar tetangga. Bravo Panitia Karang Taruna!',
    sticker: '👏',
    timestamp: 'Kemarin',
    likes: 18
  },
  {
    id: 'w-4',
    name: 'Mas Farhan (Karang Taruna)',
    houseNumber: 'Rumah No. 18',
    message: 'Jangan lupa hadir ya bapak ibu dan adik-adik di Malam Tasyakuran Potong Tumpeng tanggal 15 Agustus! Ada doorprize menarik!',
    sticker: '🎁',
    timestamp: '2 hari lalu',
    likes: 15
  }
];
